import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Forgetpassword extends StatefulWidget {
  const Forgetpassword({super.key});

  @override
  State<Forgetpassword> createState() => _ForgetpasswordState();
}

class _ForgetpasswordState extends State<Forgetpassword> {
  GlobalKey<FormState> _myform=GlobalKey<FormState>();
  TextEditingController _emailcontroller=TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFEDEDED),
      appBar: AppBar(title: Text("Forget Password",style: TextStyle(color: Colors.white),),backgroundColor:Color(0xFF0F172A) ,),
      body: Column(
        children: [
          Container(
            margin: EdgeInsets.all(20),
            alignment: Alignment.center,
            child: Image.asset("assets/forgetpassword.jpeg",
              width:384,
              height:290,
              fit:BoxFit.cover,
            ),
          ),
          SizedBox(height: 20,),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 30,horizontal: 20),
            child: Form(
                key: _myform,
                child: TextFormField(
                  controller: _emailcontroller,
                  decoration:
                  InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      labelText: "Email",
                      prefixIcon: Icon(Icons.email_rounded),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: BorderSide(color: Colors.transparent),
                      )
                  ),
                  validator: (value){
                    if(value==null || value.isEmpty){
                      return "please enter your email";
                    } else if(value!="janamohamed@gmail"){
                      return "email is not valid";
                    }
                    return null;
                  },
                )
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10),
            child: ElevatedButton(onPressed: (){},
                style: ElevatedButton.styleFrom(
                    backgroundColor:Color(0xFF0F172A),
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(vertical: 10,horizontal:135 )
                )
                ,child: Text("Reset Password",style: TextStyle(fontSize: 16),)),
          ),

          Padding(
            padding: const EdgeInsets.symmetric(vertical: 0,horizontal: 35),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                TextButton(onPressed: (){
                  Navigator.pop(context);
                }, child:Text("Back to login",style: TextStyle(color: Colors.grey),) ),
              ],
            ),
          )

        ],
      ),
    );
  }
}